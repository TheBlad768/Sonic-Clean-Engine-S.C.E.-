
#include "logger.h"

enum LogLevel logLevel = LOGGER_DEFAULT_LEVEL;
