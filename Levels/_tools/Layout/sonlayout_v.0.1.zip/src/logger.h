
#pragma once

#include <stdarg.h>
#include <stdio.h>

#ifndef LOGGER_NAME
	#define LOGGER_NAME "unknown"
#endif

enum LogLevel {
	DEBUG = 0,
	INFO,
	WARNING,
	ERROR
};
#ifndef LOGGER_DEFAULT_LEVEL
	#define LOGGER_DEFAULT_LEVEL DEBUG
#endif

extern enum LogLevel logLevel;

static const char* logLevelText[] = {
	"DEBUG: [" LOGGER_NAME "] ",
	"INFO: [" LOGGER_NAME "] ",
	"WARNING: [" LOGGER_NAME "] ",
	"ERROR: [" LOGGER_NAME "] "
};

static inline void setLogLevel(enum LogLevel level) {
	logLevel = level;
}

static inline void printLog(enum LogLevel level, const char * message, ...) {
	if (level < logLevel) {
		return;
	}

	fputs(logLevelText[level], stderr);
	va_list args;
	va_start(args, message);
	vfprintf(stderr, message, args);
	va_end(args);
	fputs("\n", stderr);
}
