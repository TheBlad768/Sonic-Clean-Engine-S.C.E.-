
#define LOGGER_NAME "layout-s3k"
#include "logger.h"

#include "layout-s3k.h"
#include "layout-s3k-base.h"
#include "buffer.h"
#include "sonlayout.h"

#define S3K_BASE_POINTER_ADDRESS 0x8000

int loadCombinedLayout_S3K(const Buffer* inBuff, CombinedLayoutData* outCombinedLayout) {
	return loadCombinedLayout_S3KBased(inBuff, outCombinedLayout, S3K_BASE_POINTER_ADDRESS, BYTE);
}

int loadLayout_S3K(const Buffer* inBuff, LayoutData* const outLayout, enum CombinedLayoutType layoutType) {
	return loadLayout_S3KBased(inBuff, outLayout, layoutType, S3K_BASE_POINTER_ADDRESS, BYTE);
}

int convertFromCombinedLayout_S3K(const CombinedLayoutData* inCombinedLayoutData, Buffer* outBuff) {
	return convertFromCombinedLayout_S3KBased(inCombinedLayoutData, outBuff, S3K_BASE_POINTER_ADDRESS, BYTE);
}
