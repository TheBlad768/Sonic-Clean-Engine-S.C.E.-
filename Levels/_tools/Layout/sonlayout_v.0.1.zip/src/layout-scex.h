
#include "sonlayout.h"
#include "buffer.h"

int loadLayout_SCEX(const Buffer* inBuff, LayoutData* outLayout, enum CombinedLayoutType layoutType);

int loadCombinedLayout_SCEX(const Buffer* inBuff, CombinedLayoutData* outCombinedLayout);

int convertFromCombinedLayout_SCEX(const CombinedLayoutData * inCombinedLayoutData, Buffer* outBuff);
