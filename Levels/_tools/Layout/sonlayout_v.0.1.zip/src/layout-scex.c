
#define LOGGER_NAME "layout-SCEX"
#include "logger.h"

#include "layout-scex.h"
#include "layout-s3k-base.h"
#include "buffer.h"
#include "sonlayout.h"

#define SCEX_BASE_POINTER_ADDRESS 0

int loadLayout_SCEX(const Buffer* inBuff, LayoutData* outLayout, enum CombinedLayoutType layoutType) {
	return loadLayout_S3KBased(inBuff, outLayout, layoutType, SCEX_BASE_POINTER_ADDRESS, WORD);
}

int loadCombinedLayout_SCEX(const Buffer* inBuff, CombinedLayoutData* outCombinedLayout) {
	return loadCombinedLayout_S3KBased(inBuff, outCombinedLayout, SCEX_BASE_POINTER_ADDRESS, WORD);
}

int convertFromCombinedLayout_SCEX(const CombinedLayoutData* inCombinedLayoutData, Buffer* outBuff) {
	return convertFromCombinedLayout_S3KBased(inCombinedLayoutData, outBuff, SCEX_BASE_POINTER_ADDRESS, WORD);
}
