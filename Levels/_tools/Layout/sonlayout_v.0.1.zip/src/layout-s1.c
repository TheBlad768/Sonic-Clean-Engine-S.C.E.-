
#include <assert.h>
#include <stdint.h>

#define LOGGER_NAME "layout-s1"
#include "logger.h"

#include "sonlayout.h"
#include "buffer.h"


#define S1_MAX_LAYOUT_WIDTH 64
#define S1_MAX_LAYOUT_HEIGHT 8


int loadLayout_S1(const Buffer* inBuff, LayoutData* outLayout) {
	if (inBuff->length < 3) {
		return -1;
	}

	uint16_t width = ((uint8_t*)inBuff->data)[0] + 1;
	uint16_t height = ((uint8_t*)inBuff->data)[1] + 1;
	const uint16_t maxWidth = S1_MAX_LAYOUT_WIDTH;
	const uint16_t maxHeight = S1_MAX_LAYOUT_HEIGHT;
	if (inBuff->length != 2 + width * height) {
		printLog(ERROR, "Input buffer is not a valid layout (length=%ld)", inBuff->length);
		return -2;
	}

	uint8_t *rawChunkIds = (uint8_t*)inBuff->data + 2;

	outLayout->attributes = CHUNKS_256x256;
	if (height == outLayout->maxHeight) {
		printLog(INFO, "Set LOOP_Y attribute");
		outLayout->attributes |= LOOP_Y;
	}

	const int createLayoutResult = createLayoutData(outLayout, width, height, maxWidth, maxHeight);
	if (createLayoutResult != 0) {
		printLog(ERROR, "Couldn't allocate layout data (code=%d)", createLayoutResult);
		return 2;
	}

	for (size_t i = 0; i < width*height; ++i) {
		const uint8_t chunkId = rawChunkIds[i];
		outLayout->chunks[i].value = chunkId & 0x7F;
		outLayout->attributes = (chunkId & 0x80) ? LOOP_CHUNK : 0;
	}

	return 0;
}

static inline int isLayoutDataConvertible(const LayoutData* layoutData) {
	assert(layoutData);

	/* Make sure layouts fit */
	if (layoutData->height > S1_MAX_LAYOUT_HEIGHT || layoutData->width > S1_MAX_LAYOUT_WIDTH) {
		printLog(ERROR, "Layout is too large (width=%d, height=%d)", layoutData->width, layoutData->height);
		return -1;
	}

	/* 128x128 chunks aren't supported */
	if ((layoutData->attributes & CHUNKS_256x256) != CHUNKS_256x256) {
		printLog(ERROR, "Can't use layout with 128x128 chunks");
		return -2;
	}

	/* Make sure chunk data is compatible */
	ChunkData * chunkData = layoutData->chunks;
	const int chunkDataSize = layoutData->width * layoutData->height;
	for (int i = 0; i < chunkDataSize; ++i, ++chunkData) {
		if (chunkData->value > 0xFF) {
			printLog(ERROR, "Chunk ID too large (id=%X)", chunkData->value);
			return -3;
		}
		if (chunkData->attributes & ~LOOP_CHUNK) {
			printLog(ERROR, "Unsupported chunk attributes (attributes=%X)", chunkData->attributes);
			return -4;
		}
	}

	return 0;
}

int convertFromLayout_S1(const LayoutData* inLayoutData, Buffer* outBuff) {
	assert(inLayoutData && outBuff);

	/* Make sure layout is convertible */
	if (isLayoutDataConvertible(inLayoutData) != 0) {
		printLog(ERROR, "Layout data is not convertible");
		return 1;
	}

	const size_t headerSize = 2;
	const size_t dataSize = inLayoutData->width * inLayoutData->height;
	const size_t outBuffLength = headerSize + dataSize;

	const int createBufferResult = createBuffer(outBuff, outBuffLength);
	if (createBufferResult != 0) {
		printLog(ERROR, "Couldn't allocate output buffer (code=%d)", createBufferResult);
		return 2;
	}

	/* Header */
	uint8_t * outBuffData = outBuff->data;
	*outBuffData++ = inLayoutData->width - 1;
	*outBuffData++ = inLayoutData->height - 1;

	/* Dump layout data */
	ChunkData * chunkData = inLayoutData->chunks;
	for (uint16_t i = 0; i < inLayoutData->width * inLayoutData->height; ++i) {
		uint8_t rawChunkId = chunkData->value;
		if (chunkData->attributes & LOOP_CHUNK) {
			rawChunkId |= 0x80;
		}
		*outBuffData++ = rawChunkId;
		chunkData++;
	}

	assert(outBuffData - (uint8_t *)outBuff->data == outBuff->length);

	return 0;
}
