
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LOGGER_NAME "main"
#include "logger.h"

#include "compat/getopt.h"
#include "sonlayout.h"
#include "buffer.h"

#include "layout-s3k.h"
#include "layout-sce.h"
#include "layout-scex.h"

typedef int (*LoadCombinedLayoutFunction)(const Buffer* const inBuff, CombinedLayoutData* outCombinedLayout);
typedef int (*ConvertFromCombinedLayoutFunction)(const CombinedLayoutData* inCombinedLayoutData, Buffer* outBuff);

typedef struct {
	LoadCombinedLayoutFunction loadCombinedLayout;
	ConvertFromCombinedLayoutFunction convertFromCombinedLayout;
} FormatHandler;

int loadCombinedLayout_NotImplemented(const Buffer* const _inBuff, CombinedLayoutData* _outCombinedLayout) {
	printLog(ERROR, "Combined layout loading is not supported by this format.");
	return -1;
}

int convertFromCombinedLayout_NotImplemented(const CombinedLayoutData* inCombinedLayoutData, Buffer* outBuff) {
	printLog(ERROR, "Combined layout conversion is not supported by this format.");
	return -1;
}

static const char* supportedFormats[] = {"s1", "s3k", "sce", "scex"};
static const FormatHandler formatHandlers[] = {
	{	/* S1 */
		.loadCombinedLayout = &loadCombinedLayout_NotImplemented,
		.convertFromCombinedLayout = &convertFromCombinedLayout_NotImplemented
	},
	{	/* S3K */
		.loadCombinedLayout = &loadCombinedLayout_S3K,
		.convertFromCombinedLayout = &convertFromCombinedLayout_S3K
	},
	{	/* SCE */
		.loadCombinedLayout = &loadCombinedLayout_SCE,
		.convertFromCombinedLayout = &convertFromCombinedLayout_SCE
	},
	{	/* SCEX */
		.loadCombinedLayout = &loadCombinedLayout_SCEX,
		.convertFromCombinedLayout = &convertFromCombinedLayout_SCEX
	},
};

const char * usageMessage = 
	"SonLayout v.0.1 - Sonic layout conversion utility\n"
	"(c) 2024, Vladikcomper\n"
	"\n"
	"USAGE:\n"
	"	sonlayout [-q] -i INFORMAT -o OUTFORMAT INFILE OUTFILE\n"
	"\n"
	"OPTIONS:\n"
	"	-i INFORMAT - Specifies input format\n"
	"	-o OUTFORMAT - Specifies output format (format to convert to)\n"
	"	-q - Quiet mode (log errors only)\n"
	"\n"
	"SUPPORTED FORMATS:\n"
	"	s1 - Sonic 1 layout (256x256, FG and BG separated)\n"
	"	s3k - Sonic 3K combined layout (FG+BG)\n"
	"	sce - Sonic Clean Engine combined layout (FG+BG)\n"
	"	scex - Extended Sonic Clean Engine combined layout (WORD-sized chunk IDs, FG+BG)\n";

int main(int argc, char *argv[]) {

	if (argc < 5) {
		fputs(usageMessage, stderr);
		return -1;
	}

	const char * inputFilePath = NULL;
	const char * outputFilePath = NULL;
	const FormatHandler* inputFormatHandler = NULL;
	const FormatHandler* outputFormatHandler = NULL;

	/* Parse options */
	int opt = 0;
	while ((opt = getopt(argc, argv, "qi:o:")) != -1) {
		switch (opt) {
		case 'q': {
			setLogLevel(ERROR);
			break;
		}
		case 'o':
		case 'i': {
			int formatHandlerId = -1;
			for (int i = 0; i < sizeof(supportedFormats)/sizeof(supportedFormats[0]); ++i) {
				if (strcmp(optarg, supportedFormats[i]) == 0) {
					formatHandlerId = i;
					break;
				}
			}
			if (formatHandlerId == -1) {
				fprintf(stderr, "Format not recognized: %s\nPlease use any of: s1, s3k, sce, scex", optarg);
				exit(EXIT_FAILURE);
			}
			if (opt == 'i' && inputFormatHandler == NULL) {
				inputFormatHandler = &formatHandlers[formatHandlerId];
				printLog(DEBUG, "Setting input format handler (format=%s, formatHandlerId=%d)", optarg, formatHandlerId);
			}
			else if (opt == 'o' && outputFormatHandler == NULL) {
				outputFormatHandler = &formatHandlers[formatHandlerId];
				printLog(DEBUG, "Setting output format handler (format=%s, formatHandlerId=%d)", optarg, formatHandlerId);
			}
			else {
				fprintf(stderr, "Multiple instances of format specifier or broken argument parsing\n");
				exit(EXIT_FAILURE);				
			}
			break;
		}

		default:
			fprintf(stderr, "Unknown option: %c\n", opt);
			exit(EXIT_FAILURE);
		}
	}

	/* Parse non-option arguments */
	if (optind < argc) {
		inputFilePath = argv[optind++];
		printLog(DEBUG, "Setting input file path (path=%s)", inputFilePath);
	}
	if (optind < argc) {
		outputFilePath = argv[optind++];
		printLog(DEBUG, "Setting output file path (path=%s)", outputFilePath);
	}

	/* Validate options */
	if (inputFilePath == NULL) {
		fprintf(stderr, "Input file not specified\n");
		exit(EXIT_FAILURE);
	}
	if (outputFilePath == NULL) {
		fprintf(stderr, "Output file not specified\n");
		exit(EXIT_FAILURE);
	}
	if (inputFormatHandler == NULL) {
		fprintf(stderr, "Input format not specified\n");
		exit(EXIT_FAILURE);
	}
	if (outputFormatHandler == NULL) {
		fprintf(stderr, "Output format not specified\n");
		exit(EXIT_FAILURE);
	}

	/* Get input file */
	Buffer inBuff;
	const int createBufferResult = createBufferFromFile(&inBuff, inputFilePath);
	if (createBufferResult != 0) {
		fprintf(stderr, "Load input file (file='%s', code=%d)\n", inputFilePath, createBufferResult);
		exit(EXIT_FAILURE);
	}
	CombinedLayoutData inCombinedLayout;
	const int loadCombinedLayoutResult = (*inputFormatHandler->loadCombinedLayout)(&inBuff, &inCombinedLayout);
	if (loadCombinedLayoutResult != 0) {
		fprintf(stderr, "Couldn't load data in input format (code=%d)\n", loadCombinedLayoutResult);
		deleteBuffer(&inBuff);
		exit(EXIT_FAILURE);
	}

	/* Generate output file */
	Buffer outBuff;
	const int convertLayoutResult = (*outputFormatHandler->convertFromCombinedLayout)(&inCombinedLayout, &outBuff);
	if (convertLayoutResult) {
		printf("Couldn't convert to target format (code=%d)\n", convertLayoutResult);
		deleteBuffer(&inBuff);
		exit(EXIT_FAILURE);
	}
	const int writeBufferResult = writeBufferToFile(&outBuff, outputFilePath);
	if (writeBufferResult) {
		printf("Couldn't save output file (code=%d)\n", writeBufferResult);
		deleteBuffer(&inBuff);
		exit(EXIT_FAILURE);
	}

	deleteBuffer(&inBuff);
	deleteBuffer(&outBuff);
	// TODO: Free layout data
	return 0;
}
