
#include "sonlayout.h"
#include "buffer.h"

int loadLayout_SCE(const Buffer* inBuff, LayoutData* outLayout, enum CombinedLayoutType layoutType);

int loadCombinedLayout_SCE(const Buffer* inBuff, CombinedLayoutData* outCombinedLayout);

int convertFromCombinedLayout_SCE(const CombinedLayoutData * inCombinedLayoutData, Buffer* outBuff);
