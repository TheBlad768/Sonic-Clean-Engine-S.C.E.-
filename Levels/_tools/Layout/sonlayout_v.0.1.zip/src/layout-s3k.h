
#include "sonlayout.h"
#include "buffer.h"

int loadLayout_S3K(const Buffer* inBuff, LayoutData* outLayout, enum CombinedLayoutType layoutType);

int loadCombinedLayout_S3K(const Buffer* inBuff, CombinedLayoutData* outCombinedLayout);

int convertFromCombinedLayout_S3K(const CombinedLayoutData* inCombinedLayoutData, Buffer* outBuff);
