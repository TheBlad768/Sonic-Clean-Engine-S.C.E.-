
#include <stdlib.h>
#ifndef LOGGER_NAME
	#error "Please define LOGGER_NAME before including this header"
#endif
#ifndef S3KBASED_MAX_LAYOUT_WIDTH
	#define S3KBASED_MAX_LAYOUT_WIDTH 0x100 /* TODO: verify this */
#endif
#ifndef S3KBASED_MAX_LAYOUT_HEIGHT
	#define S3KBASED_MAX_LAYOUT_HEIGHT 0x20 /* TODO: 0x10 for Ice Cap 1? */
#endif

#include "logger.h"

#include "compat/byteswap.h"
#include "sonlayout.h"
#include "buffer.h"

enum S3KBasedChunkIdSize {
	BYTE = 1,
	WORD = 2,
};

static inline int loadLayout_S3KBased(
	const Buffer* inBuff,
	LayoutData* outLayout,
	enum CombinedLayoutType layoutType,
	uint16_t basePointerAddress,
	enum S3KBasedChunkIdSize chunkIdSize
) {
	assert(inBuff && outLayout);	/* don't tolerate NULL's */

	if (inBuff->length < 0x88 + 1) {
		printLog(ERROR, "Input buffer is not a valid layout (length=%ld)", inBuff->length);
		return 1;
	}

	const size_t layoutHeaderOffset = layoutType == FG ? 0 : 2;

	const uint16_t width = bswap_16(*(uint16_t*)getBufferPointerAt(inBuff, layoutHeaderOffset + 0));
	const uint16_t height = bswap_16(*(uint16_t*)getBufferPointerAt(inBuff, layoutHeaderOffset + 4));
	const uint16_t maxWidth = S3KBASED_MAX_LAYOUT_WIDTH;
	const uint16_t maxHeight = S3KBASED_MAX_LAYOUT_HEIGHT;
	printLog(INFO, "Reading layout (layoutType=%d, width=%d, height=%d)", layoutType, width, height);

	const int createLayoutResult = createLayoutData(outLayout, width, height, maxWidth, maxHeight);
	if (createLayoutResult != 0) {
		printLog(ERROR, "Couldn't allocate layout data (layoutType=%d, code=%d)", layoutType, createLayoutResult);
		return 2;
	}

	outLayout->attributes = 0;
	if (height == maxHeight) {
		printLog(INFO, "Set LOOP_Y attribute (layoutType=%d)", layoutType);
		outLayout->attributes |= LOOP_Y;
	}

	uint16_t* chunkRowPointers = getBufferPointerAt(inBuff, 8 + layoutHeaderOffset);
	ChunkData * chunkDataPtr = outLayout->chunks;

	#define LOAD_CHUNK_DATA(T,CONV) \
		for (int i = 0; i < height * 2; i += 2) { \
			const uint16_t chunkRowOffset = bswap_16(chunkRowPointers[i]) - basePointerAddress; \
			if (inBuff->length < chunkRowOffset + width * sizeof(T)) { \
				printLog(ERROR, "Encountered out of bounds layout row pointer or data (chunkRowOffset=%X)", chunkRowOffset); \
				return 10; \
			} \
			\
			const T * rawChunkData = getBufferPointerAt(inBuff, chunkRowOffset); \
			for (int j = 0; j < width; ++j) { \
				*chunkDataPtr++ = (ChunkData){ \
					.value = CONV(rawChunkData[j]), \
					.attributes = 0 \
				}; \
			} \
		}

	if (chunkIdSize == BYTE) {
		LOAD_CHUNK_DATA(uint8_t, )
	}
	else if (chunkIdSize == WORD) {
		LOAD_CHUNK_DATA(uint16_t, bswap_16)
	}
	else {
		printLog(ERROR, "Unkown chunk id size (chunkIdSize=%d)", chunkIdSize);
	}

	#undef LOAD_CHUNK_DATA

	return 0;
}

static inline int loadCombinedLayout_S3KBased(
	const Buffer* inBuff,
	CombinedLayoutData* outCombinedLayout,
	uint16_t basePointerAddress,
	enum S3KBasedChunkIdSize chunkIdSize
) {
	assert(inBuff && outCombinedLayout);	/* don't tolerate NULL's */

	const int loadFgResult = loadLayout_S3KBased(inBuff, &outCombinedLayout->fg, FG, basePointerAddress, chunkIdSize);
	if (loadFgResult != 0) {
		printLog(ERROR, "Couldn't load FG layout (code=%d)", loadFgResult);
		return 100 + loadFgResult;
	}

	const int loadBgResult = loadLayout_S3KBased(inBuff, &outCombinedLayout->bg, BG, basePointerAddress, chunkIdSize);
	if (loadBgResult != 0) {
		printLog(ERROR, "Couldn't load BG layout (code=%d)", loadBgResult);
		return 200 + loadFgResult;
	}

	return 0;
}

static inline int isLayoutDataConvertibleToS3KBased(
	const LayoutData * layoutData,
	enum S3KBasedChunkIdSize chunkIdSize
) {
	assert(layoutData);

	/* Make sure layouts fit */
	if (layoutData->height > S3KBASED_MAX_LAYOUT_HEIGHT || layoutData->width > S3KBASED_MAX_LAYOUT_WIDTH) {
		printLog(ERROR, "Layout is too large (width=%d, height=%d)", layoutData->width, layoutData->height);
		return -1;
	}

	/* 256x256 chunks aren't supported */
	if (layoutData->attributes & CHUNKS_256x256) {
		printLog(ERROR, "Can't use layout with 256x256 chunks");
		return -2;
	}

	/* Make sure chunk data is compatible */
	ChunkData * chunkData = layoutData->chunks;
	const int chunkDataSize = layoutData->width * layoutData->height;
	for (int i = 0; i < chunkDataSize; ++i, ++chunkData) {
		if (chunkIdSize == BYTE && chunkData->value > 0xFF) {
			printLog(ERROR, "Chunk ID too large (id=%X)", chunkData->value);
			return -3;
		}
		if (chunkData->attributes != 0) {
			printLog(ERROR, "Unsupported chunk attributes (attributes=%X)", chunkData->attributes);
			return -4;
		}
	}

	return 0;
}

static inline int convertFromCombinedLayout_S3KBased(
	const CombinedLayoutData* inCombinedLayoutData,
	Buffer* outBuff,
	uint16_t basePointerAddress,
	enum S3KBasedChunkIdSize chunkIdSize	
) {
	assert(inCombinedLayoutData && outBuff);

	/* Make sure layout data is convertible */
	if (
		isLayoutDataConvertibleToS3KBased(&inCombinedLayoutData->fg, chunkIdSize) != 0 ||
		isLayoutDataConvertibleToS3KBased(&inCombinedLayoutData->bg, chunkIdSize) != 0
	) {
		printLog(ERROR, "Layout data is not convertible");
		return 1;
	}

	const size_t headerSize = 8;
	const size_t pointerTableSize = S3KBASED_MAX_LAYOUT_HEIGHT * 2 * 2;
	const size_t fgDataSize = inCombinedLayoutData->fg.height * inCombinedLayoutData->fg.width * chunkIdSize;
	const size_t bgDataSize = inCombinedLayoutData->bg.height * inCombinedLayoutData->bg.width * chunkIdSize;
	const size_t outBuffLength = headerSize + pointerTableSize + fgDataSize + bgDataSize;

	const int createBufferResult = createBuffer(outBuff, outBuffLength);
	if (createBufferResult != 0) {
		printLog(ERROR, "Couldn't allocate output buffer (code=%d)", createBufferResult);
		return 2;
	}

	uint16_t * outBuffHeader = outBuff->data;

	/* Header: fill in width */
	*outBuffHeader++ = bswap_16(inCombinedLayoutData->fg.width);	/* OFFSET 0x00 */
	*outBuffHeader++ = bswap_16(inCombinedLayoutData->bg.width);	/* OFFSET 0x02 */
	*outBuffHeader++ = bswap_16(inCombinedLayoutData->fg.height);	/* OFFSET 0x04 */
	*outBuffHeader++ = bswap_16(inCombinedLayoutData->bg.height);	/* OFFSET 0x06 */

	#define SAVE_CHUNK_DATA(T, CONV) \
		T * outBuffChunkData = getBufferPointerAt(outBuff, headerSize + pointerTableSize); \
		SAVE_CHUNK_DATA_LOOP(fg, 0, CONV) \
		SAVE_CHUNK_DATA_LOOP(bg, 1, CONV) \
		assert((uint8_t*)outBuffHeader <= (uint8_t*)outBuff->data + headerSize + pointerTableSize);

	#define SAVE_CHUNK_DATA_LOOP(LAYER, HEADER_OFFSET, CONV) \
		{ \
			uint16_t * outBuffPointerTable = outBuffHeader + HEADER_OFFSET; \
			ChunkData * chunkData = inCombinedLayoutData->LAYER.chunks; \
			for (uint16_t y = 0; y < inCombinedLayoutData->LAYER.height; ++y) { \
				*outBuffPointerTable = bswap_16(getBufferPointerOffset(outBuff, outBuffChunkData) + basePointerAddress);	/* setup start pointer */ \
				outBuffPointerTable += 2;	/* skip entry for another layer */ \
				for (uint16_t x = 0; x < inCombinedLayoutData->LAYER.width; ++x) { \
					*outBuffChunkData++ = CONV((*chunkData++).value); \
				} \
			} \
		}

	if (chunkIdSize == BYTE) {
		SAVE_CHUNK_DATA(uint8_t, )
	}
	else if (chunkIdSize == WORD) {
		SAVE_CHUNK_DATA(uint16_t, bswap_16)
	}
	else {
		deleteBuffer(outBuff);
		printLog(ERROR, "Unkown chunk id size (chunkIdSize=%d)", chunkIdSize);
		return -1;
	}

	#undef SAVE_CHUNK_DATA
	#undef SAVE_CHUNK_DATA_LOOP

	/* Header and data should never overlap */
	assert((uint8_t*)outBuffHeader <= (uint8_t*)outBuff->data + headerSize + pointerTableSize);

	return 0;
}
