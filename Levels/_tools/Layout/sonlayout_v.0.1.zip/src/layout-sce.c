
#define LOGGER_NAME "layout-sce"
#include "logger.h"

#include "layout-sce.h"
#include "layout-s3k-base.h"
#include "buffer.h"
#include "sonlayout.h"

#define SCE_BASE_POINTER_ADDRESS 0

int loadLayout_SCE(const Buffer* inBuff, LayoutData* outLayout, enum CombinedLayoutType layoutType) {
	return loadLayout_S3KBased(inBuff, outLayout, layoutType, SCE_BASE_POINTER_ADDRESS, BYTE);
}

int loadCombinedLayout_SCE(const Buffer* inBuff, CombinedLayoutData* outCombinedLayout) {
	return loadCombinedLayout_S3KBased(inBuff, outCombinedLayout, SCE_BASE_POINTER_ADDRESS, BYTE);
}

int convertFromCombinedLayout_SCE(const CombinedLayoutData* inCombinedLayoutData, Buffer* outBuff) {
	return convertFromCombinedLayout_S3KBased(inCombinedLayoutData, outBuff, SCE_BASE_POINTER_ADDRESS, BYTE);
}
