
#pragma once

#include "sonlayout.h"
#include "buffer.h"

int loadLayout_S1(const Buffer* inBuff, LayoutData* outLayout);

int convertFromLayout_S1(const LayoutData* inLayoutData, Buffer* outBuff);
