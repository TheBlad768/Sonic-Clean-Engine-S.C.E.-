
#pragma once

#include <assert.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <stdio.h>

#ifndef BUFFER_MAX_LENGTH
	#define BUFFER_MAX_LENGTH 1*1024*1024 /* 1 MiB */
#endif

typedef struct {
	size_t length;
	void * data;
} Buffer;

static inline int deleteBuffer(Buffer* const buff) {
	if (buff->data) {
		free(buff->data);
	}
	memset(buff, 0, sizeof(Buffer));

	return 0;
}

static inline int createBufferFromFile(Buffer* buff, const char * path) {
	assert(buff && path);

	int returnCode = 0;
	FILE * file = fopen(path, "rb");
	void * data = NULL;

	if (file == NULL) {
		returnCode = -1;
		goto quit;
	}

	{
		fseek(file, 0, SEEK_END);
		const size_t fileSize = ftell(file);
		if (fileSize > BUFFER_MAX_LENGTH) {
			returnCode = -2;
			goto cleanupAndQuit2;
		}
		fseek(file, 0, SEEK_SET);

		data = malloc(fileSize);
		if (data == NULL) {
			returnCode = -3;
			goto cleanupAndQuit2;
		}

		const size_t readResult = fread(data, fileSize, 1, file);
		if (readResult != 1) {
			returnCode = -4;
			goto cleanupAndQuit1;
		}

		*buff = (Buffer){
			.length = fileSize,
			.data = data
		};
	}

	assert(returnCode == 0);
	goto cleanupAndQuit2;

cleanupAndQuit1:
	free(data);
cleanupAndQuit2:
	fclose(file);
quit:
	return returnCode;
}

static inline int writeBufferToFile(const Buffer* buff, const char * path) {
	assert(buff);

	int returnCode = 0;

	FILE * file = fopen(path, "wb");
	if (file == NULL) {
		returnCode = -1;
		goto quit;
	}

	const int writeResult = fwrite(buff->data, buff->length, 1, file);
	if (writeResult != 1) {
		returnCode = -2;
		goto cleanupAndQuit;
	}

	assert(returnCode == 0);

cleanupAndQuit:
	fclose(file);
quit:
	return 0;
}

static inline int createBuffer(Buffer* buff, size_t length) {
	if (length > BUFFER_MAX_LENGTH) {
		return -2;
	}

	void * data = calloc(length, 1);
	if (data == NULL) {
		return -1;
	}

	*buff = (Buffer){
		.length = length,
		.data = data,
	};

	return 0;
}

static inline int getBufferPointerOffset(const Buffer * buff, const void * buffDataPtr) {
	assert(buff && buffDataPtr);

	return (uint8_t*)buffDataPtr - (uint8_t*)buff->data;
}

static inline void * getBufferPointerAt(const Buffer * buff, size_t offset) {
	assert(buff);

	return (uint8_t*)buff->data + offset;
}
