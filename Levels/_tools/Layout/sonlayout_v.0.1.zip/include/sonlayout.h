
#pragma once

#include <assert.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>


enum LayoutAttributes {
	/* Set if chunks aren't 128x128 */
	CHUNKS_256x256 = 1,
	/* Layout loops on X axis */
	LOOP_X = 2,
	/* Layout loops on Y axis */
	LOOP_Y = 4,
};
enum LayoutChunkAttributes {
	LOOP_CHUNK = 1,
	FLIP_X = 2,
	FLIP_Y = 4,
};

typedef struct {
	int16_t value;
	uint8_t attributes;
} ChunkData;

typedef struct {
	uint16_t width;
	uint16_t height;
	uint16_t maxWidth;
	uint16_t maxHeight;
	ChunkData * chunks;
	uint8_t attributes;
} LayoutData;

enum CombinedLayoutType {
	FG = 1,
	BG,
};

typedef struct {
	LayoutData fg;
	LayoutData bg;
} CombinedLayoutData;

static inline int deleteLayoutData(LayoutData* layout) {
	if (layout->chunks) {
		free(layout->chunks);
	}

	memset(layout, 0, sizeof(LayoutData));

	return 0;
}

static inline int createLayoutData(
	LayoutData* layout,
	uint16_t width,
	uint16_t height,
	uint16_t maxWidth,
	uint16_t maxHeight
) {
	/* Allocate data for chunks according to layout's size */
	ChunkData* const chunks = (ChunkData*)calloc(width * height, sizeof(ChunkData));
	if (chunks == NULL) {
		return -1;
	}

	*layout = (LayoutData){
		.width = width,
		.height = height,
		.maxWidth = maxWidth,
		.maxHeight = maxHeight,
		.chunks = chunks
	};

	return 0;
}
